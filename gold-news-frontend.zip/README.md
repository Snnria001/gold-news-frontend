# Gold News Frontend
React PWA for displaying news and price predictions.